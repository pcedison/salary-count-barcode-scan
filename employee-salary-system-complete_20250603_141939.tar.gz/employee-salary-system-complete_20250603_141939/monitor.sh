#!/bin/bash

# 系統監控腳本

echo "=== 員工薪資計算系統狀態 ==="
echo "時間: $(date)"
echo ""

# 檢查程序狀態
if pgrep -f "node.*server" > /dev/null; then
    echo "✓ 應用程式運行中"
    PID=$(pgrep -f "node.*server")
    echo "  程序 ID: $PID"
else
    echo "✗ 應用程式未運行"
fi

# 檢查端口
if netstat -tlnp 2>/dev/null | grep ":5000 " > /dev/null; then
    echo "✓ 端口 5000 開放"
else
    echo "✗ 端口 5000 未開放"
fi

# 檢查資料庫連接
echo ""
echo "檢查資料庫連接..."
npm run db:check 2>/dev/null

# 檢查磁碟空間
echo ""
echo "磁碟使用狀況:"
df -h / | tail -1

# 檢查記憶體使用
echo ""
echo "記憶體使用狀況:"
free -h | grep Mem

echo ""
echo "=== 監控完成 ==="
