#!/bin/bash

# 開發模式啟動腳本

if [ ! -f .env ]; then
    echo "錯誤: .env 檔案不存在，請先執行 ./deploy.sh"
    exit 1
fi

echo "啟動開發模式..."
npm run dev
