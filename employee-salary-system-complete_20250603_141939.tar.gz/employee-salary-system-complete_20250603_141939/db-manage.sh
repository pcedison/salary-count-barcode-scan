#!/bin/bash

# 資料庫管理腳本

case "$1" in
    "check")
        echo "檢查資料庫連接..."
        npm run db:check
        ;;
    "push")
        echo "推送資料庫結構..."
        npm run db:push
        ;;
    "reset")
        echo "重置資料庫..."
        npm run db:reset
        ;;
    "backup")
        echo "創建資料庫備份..."
        node scripts/backup-create.js
        ;;
    *)
        echo "用法: $0 {check|push|reset|backup}"
        echo ""
        echo "  check  - 檢查資料庫連接"
        echo "  push   - 推送資料庫結構"
        echo "  reset  - 重置資料庫"
        echo "  backup - 創建備份"
        ;;
esac
