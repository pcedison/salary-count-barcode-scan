#!/bin/bash

# 快速啟動腳本

if [ ! -f .env ]; then
    echo "錯誤: .env 檔案不存在，請先執行 ./deploy.sh"
    exit 1
fi

echo "啟動員工薪資計算系統..."

# 檢查是否已建置
if [ ! -d "client/dist" ]; then
    echo "正在建置前端..."
    npm run build
fi

# 啟動應用程式
npm start
