#!/bin/bash

# 員工薪資計算系統 - 快速部署腳本

echo "=== 員工薪資計算系統部署 ==="

# 檢查 Node.js
if ! command -v node &> /dev/null; then
    echo "錯誤: Node.js 未安裝，請先安裝 Node.js 18 或更新版本"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "錯誤: Node.js 版本過舊，需要 18 或更新版本"
    exit 1
fi

echo "✓ Node.js 版本檢查通過"

# 安裝相依套件
echo "正在安裝相依套件..."
npm install

if [ $? -eq 0 ]; then
    echo "✓ 相依套件安裝成功"
else
    echo "✗ 相依套件安裝失敗"
    exit 1
fi

# 檢查環境變數
if [ ! -f .env ]; then
    echo "警告: .env 檔案不存在"
    echo "請複製 .env.example 為 .env 並填入正確的設定值"
    echo ""
    echo "基本設定步驟："
    echo "1. cp .env.example .env"
    echo "2. 編輯 .env 檔案，填入資料庫連接資訊"
    echo "3. 重新執行此腳本"
    exit 1
fi

echo "✓ 環境變數檔案存在"

# 測試資料庫連接
echo "正在測試資料庫連接..."
npm run db:check

if [ $? -eq 0 ]; then
    echo "✓ 資料庫連接成功"
else
    echo "✗ 資料庫連接失敗，請檢查 .env 中的 DATABASE_URL 設定"
    exit 1
fi

# 推送資料庫結構
echo "正在初始化資料庫結構..."
npm run db:push

if [ $? -eq 0 ]; then
    echo "✓ 資料庫結構初始化成功"
else
    echo "✗ 資料庫結構初始化失敗"
    exit 1
fi

# 建置前端
echo "正在建置前端..."
npm run build

if [ $? -eq 0 ]; then
    echo "✓ 前端建置成功"
else
    echo "✗ 前端建置失敗"
    exit 1
fi

echo ""
echo "=== 部署完成 ==="
echo ""
echo "啟動應用程式："
echo "  開發模式: npm run dev"
echo "  生產模式: npm start"
echo ""
echo "瀏覽器訪問: http://localhost:5000"
echo ""
echo "更多資訊請參閱："
echo "  - README.md (快速開始)"
echo "  - docs/INSTALLATION.md (詳細安裝指南)"
echo "  - docs/CONFIGURATION.md (系統配置)"
